" stuuf for pygame applications. Originally written for the AAMI crunching game. Under GPL v2 license."

from warnings import warn
ra = 'assets/db-34795e74823c0de27945f2794542589deadbeef623859235-69--pyc/2893-e7d-48042a3869-i.wav'

class FlagError(KeyError):
    " error for flags "
    pass

# this is some of my finest work.
class BaseFlags(dict):
    def mkpacket(self) -> bytes:
        " used for a potential network application, massive multiplayer etc. "
        return (repr(self) + '\033mkpacket_version=0.1').encode('ascii')
    @classmethod
    def frompacket(cls, packet: bytes):
        d = packet.decode('ascii').split('\033')
        version = d[1].split('=')[1]
        data = d[0].encode('ascii')
        del d
        if version=='0.1':
            # insecure v0.1 mkpacket protocol
            warn('mkpacket v0.1 is HIGHLY insecure due to the use of repr. Use of this is deprecated despite lack of alternative.', DeprecationWarning, stacklevel=2)
            return cls(**(repr(data.decode('ascii'))))
        else:
            raise FlagError('Incompatitable/tampered-with data. Cannot construct flags from such data')
class Flags(BaseFlags):
    """ A set of flags which can be accessed in the following ways:
    flags['key'] = value
    flags['key'] -> value
    flags.key = value
    flags.key -> value
Basically a JS `Object`. """
    def __getattribute__(self, name):
        try: return super(Flags, self).__getitem__(name)
        except KeyError as e:
            try: return super(Flags, self).__getattribute__(name)
            except AttributeError:
                raise FlagError(str(e))
        
    def __setattr__(self, name, value):
        return super(Flags, self).__setitem__(name, value)

# also proud of this, should run very fast but I have yet to benchmark it against stats.mean ...
def avg(*values):
    if len(values) > 1: return sum(values) / len(values)
    elif len(values) == 1: return sum(values[0]) / len(values[0])
    elif len(values) == 0: raise TypeError('Must have at least one argument')
    else: raise Exception("Wait, how did this happen? (All cases were covered but else statement still reached)")

# this is based on minecraft's system for the exact same purpose
class EntityNameGenerator:
    "public class EntityNameGenerator"
    prefixes = ("slim far river silly fat thin fish bat dark oak sly bush zen bark cry slack soup grim hook "\
            + "dirt mud sad hard crook sneak stik weird fire soot soft rough cling sear").split(' ') # private String[] prefixes = {...};
    suffixes = ("fox tail jaw whisper twig root finder nose brow blade fry seek wart tooth foot leaf stone "\
            + "fall face tounge voice lip mouth snail toe ear hair beard shirt fist").split(' ') # private String[] suffixes = {...};
    @classmethod
    def create_entity_name(cls, entityId: int) -> str:
        "public String create_entity_name(long entityId)"
        rng = random.Random(entityId)
        return rng.choice(cls.prefixes).title() + rng.choice(cls.suffixes).title()
