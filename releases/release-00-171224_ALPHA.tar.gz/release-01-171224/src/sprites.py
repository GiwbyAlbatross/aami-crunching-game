"sprites for the AAMI crunching game"

__license__ = 'This is pretty important for the paid game "Crunch those AAMIs" so i don\'t really think you should be stealing this code.'

import os
import math
import random
import pygame
from pygame.locals import QUIT, KEYDOWN, USEREVENT, \
     K_w, K_a, K_s, K_d, K_SPACE, K_c, K_ESCAPE, \
     FULLSCREEN, SRCALPHA, K_F3
import stuuf
from settings import *

flags: stuuf.Flags = stuuf.BaseFlags() # should be set to proper flags
next_AAMI_speed = 4.8 + (HARDNESS // 2)

def setflags(_flags: stuuf.Flags):
    global flags
    flags = _flags
def load_deathmessage_log(log):
    global deathmsgs
    deathmsgs = log

class Hat(pygame.sprite.Sprite):
    def __init__(self, posx=(10), hat_id='basic', on=None):
        super(Hat, self).__init__()
        self.on   = on # may be player, or technically any other entity...
        self.surf = self._load_hat(hat_id)
        self.mv = [0,0]
        if on is None: self.rect = self.surf.get_rect(centerx=posx, bottom=0)
        else: self.rect = self.surf.get_rect(centerx=on.rect.centerx, bottom=on.rect.top + 8)
    def _load_hat(self, hat_id): return pygame.image.load(os.path.join('assets',
                                                        'hats', hat_id + '.png'))
    def update_logic(self):
        " only call on falling hats "
        self.mv[1] += 1
    def update_pos(self):
        on = self.on
        if on is not None:
            self.rect = self.surf.get_rect(centerx=on.rect.centerx, bottom=on.rect.top + 16)
        self.rect.move_ip(self.mv)

class Player(pygame.sprite.Sprite):
    current_hat: Hat = None
    def __init__(self, pos=scr_center, hat=None):
        # variable representing the state of the player and stuff
        self.direction = 0 # `0` is right (->)
        self.mv = (0,0) # movement vector
        self.crunching = False
        self.img_in_use= 'standing'
        self.crunched  = False # can only be crunched by Tina Fey
        self.currenthat= hat
        if hat is not None:
            self.currenthat.on = self
        # inherit from pygame.sprite.Sprite stuff (i don't get it)
        super(Player, self).__init__()
        # surfaces and images
        self.standing = pygame.transform.flip(pygame.image.load(os.path.join('assets', 'dude_standing.png')), True, False) # do convert_alhpa on blit
        self.walking1 = pygame.image.load(os.path.join('assets', 'dude_walking-1.png'))
        self.walking2 = pygame.image.load(os.path.join('assets', 'dude_walking-2.png'))
        self.surf = pygame.surface.Surface((100,100), SRCALPHA)
        self.rect = self.surf.get_rect(center=pos)
        self.surf.blit(self.standing.convert_alpha(), (0,0))
    def update_pos(self):
        self.rect.move_ip(self.mv)
        # keep player on screen
        rect = self.rect
        if rect.left < 0:
            self.rect.left = 0
        if rect.right > scr_w:
            self.rect.right = scr_w
        if rect.top <= 0:
            self.rect.top = 0
        if rect.bottom >= scr_h:
            self.rect.bottom = scr_h
    def update_keypresses(self, pressed_keys):
        #debug("updating player position")
        if pressed_keys[K_SPACE]:
            # jump
            self.jumping = True
            self.jump = 0 # goes up to 180
            self.preJumpHeight = self.rect.centery
        walking = False
        if pressed_keys[K_c]:
            self.crunching = True
        else:
            self.crunching = False
        if pressed_keys[K_w]:
            self.direction = 1
            self.rect.move_ip(0, -5)
            walking = True
        if pressed_keys[K_s]:
            self.direction = 1
            self.rect.move_ip(0, 5)
            walking = True
        if pressed_keys[K_a]:
            self.direction = 1
            self.rect.move_ip(-5, 0)
            walking = True
        if pressed_keys[K_d]:
            self.direction = 0
            self.rect.move_ip(5, 0)
            walking = True
        if walking:
            self.surf.fill((0,0,0,0))
            self.img_in_use = 'walking1'
            self.surf.blit(pygame.transform.flip(self.walking1, bool(self.direction), False), (0,0))
        else:
            self.surf.fill((0,0,0,0))
            self.img_in_use = 'standing'
            self.surf.blit(self.standing, (0,0))
    def renderhat(self, surf):
        if self.current_hat is not None:
            surf.blit(self.current_hat.surf, self.current_hat.rect)
class AAMI(pygame.sprite.Sprite):
    def __init__(self, pos=(0, scr_center[1])):
        global next_AAMI_speed
        self.mv = (int(random.gauss(next_AAMI_speed, 1)),int(random.gauss(0,0.256)))
        if not flags.you_won: next_AAMI_speed += 0.1
        else:
            next_AAMI_speed -= 0.003
        self.crunched = False # are we crunched yet?
        super(AAMI, self).__init__()
        self.surf = pygame.surface.Surface((160,80))
        self.img = pygame.image.load(os.path.join('assets', 'AAMI.png')).convert()
        self.rect = self.surf.get_rect(center=pos)
        self.surf.blit(pygame.transform.scale(self.img, (160,80)), (0,0))
    def update_pos(self):
        self.rect.move_ip(self.mv)
    def update_logic(self):
        rect = self.rect
        if (rect.right <= 0) or (rect.left > scr_w) or \
           (rect.top > scr_h) or (rect.bottom <= 0):
            self.kill("fell off the screen.")
        if self.crunched:
            self.kill("was crunched.")
    def kill(self, reason='died.'):
        print("AAMI", reason, ":( whomp whomp. ", file=deathmsgs)
        super(AAMI, self).kill()
class TinaFey(pygame.sprite.Sprite):
    speed = (((1 + HARDNESS) / 2) / 250)
    def __init__(self, pos=(200,200), target: pygame.sprite.Sprite = None, logic=True):
        super(TinaFey, self).__init__()
        self.target = target
        self.img  = pygame.image.load(os.path.join('assets', 'TinaFey.png')).convert_alpha()
        self.surf = pygame.transform.scale(self.img, (240,240))
        self.rect = self.surf.get_rect(center=pos)
        self.mv   = (random.uniform(0,2), random.uniform(0,2))
        self.last_mv = self.mv
        if logic: self.update_logic()
    def update_logic(self):
        mvx=0
        mvy=0
        selfrect = self.rect
        selfx = selfrect.centerx
        selfy = selfrect.centery
        speed = 1 / self.speed
        omvx = (random.uniform(0, scr_w) - selfx) / (-1 + speed) # go to random location
        omvy = (random.uniform(0, scr_h) - selfy) / (-1 + speed) # chosen every tick
        if self.target is not None:
            targetrect = self.target.rect
            targetx = targetrect.centerx
            targety = targetrect.centery
            mvx = (targetx - selfx) / speed
            mvy = (targety - selfy) / speed
            self.mv = [stuuf.avg(mvx, omvx), stuuf.avg(mvy, omvx)]
        else: self.mv = [omvx, omvy]
        self.last_mv = self.mv
    def update_pos(self):
        mv = self.mv
        mv[0] += (self.last_mv[0] / 2)
        mv[1] += (self.last_mv[1] / 2)
        self.rect.move_ip(mv)
