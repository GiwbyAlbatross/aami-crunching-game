" The AAMI crunching game. "

__lisence__ = 'Um the AAMI crunching game is a paid game (totally). '

import os
import math
import random
import pygame
from pygame.locals import QUIT, KEYDOWN, USEREVENT, \
     K_w, K_a, K_s, K_d, K_SPACE, K_c, K_ESCAPE, \
     FULLSCREEN, SRCALPHA, K_F3
import stuuf
from sprites import * # all sprites that were in main.py are now in sprites.py
from settings import *# so that all of the modules share the same constants...

current_fps = FPS # update sometimes I guess
scorestr = "Score: %02d"
#tinafey_likelihood = 128



def renderscore(surf):
    surf.blit(pygame.font.SysFont('', 128).render(scorestr % AAMIs_crunched, False, (240,240,242)), (10,10))
    pass
def rose_above(a1, a2, b):
    return (a1 <= b) and (not (a2 < b))

if __name__ == '__main__':
    pygame.init()

    # open a window
    scr = pygame.display.set_mode((scr_w, scr_h))
    
    # set the window title
    pygame.display.set_caption('Loading... | %s' % TITLE)
    # and icon
    #pygame.display.set_icon(pygame.image.load(os.path.join(
    # and loading screen
    scr.blit(pygame.image.load(os.path.join('assets', 'loading.png')), (0,0))

    # state variables
    running = 1
    AAMIs_crunched = 0
    you_won_fname = ...
    winning_music = ...
    flags = stuuf.Flags(running=True, you_won=False, show_hitboxes=False)
    setflags(flags) # from sprites.py

    # open logs
    deathmsgs = open('death-messages.log', 'wt')
    load_deathmessage_log(deathmsgs) # also from sprites.py

    # events
    GAME_TICK = USEREVENT + 1
    pygame.time.set_timer(GAME_TICK, (1024 // 20)) # 20 times a 'second' (second is 1024 millis)
    ADD_AAMI = USEREVENT + 2
    pygame.time.set_timer(ADD_AAMI, (512 * ((HARDNESS + 1)//2)))
    GET_FPS = USEREVENT + 3
    pygame.time.set_timer(GET_FPS, 768
                          )
    RESET = USEREVENT + 4
    #pygame.mixer.set_endevent(RESET)

    # load and initializse sounds
    pygame.mixer.init()
    crunch = pygame.mixer.Sound(file=os.path.join('assets', 'crunch.wav'))


    # sprites and groups for said sprites
    player = Player()
    currenthat: Hat = Hat(on=player)
    tina = None
    AAMIs = pygame.sprite.Group()
    tinas = pygame.sprite.Group()
    falling_hats = pygame.sprite.Group()
    # you won screen
    you_won  = ...
    you_died = pygame.image.load(os.path.join('assets', 'you_died.png')).convert_alpha()

    # clock
    tiktok = pygame.time.Clock()

    pygame.display.set_caption(TITLE)

    while running:
        try:
            for event in pygame.event.get():
                if event.type == QUIT:
                    running = 0
                    flags.running = False
                elif event.type == GAME_TICK:
                    # do game tick stuff
                    before_AAMIs_crunched = AAMIs_crunched
                    for hat in falling_hats:
                        hat.update_logic()
                    for aami in AAMIs:
                        aami.update_logic()
                        if aami.rect.colliderect(player.rect) and player.crunching \
                           and (not aami.crunched):
                            aami.crunched = True
                            AAMIs_crunched += 1
                            crunch.play()
                        if tina is not None:
                            if aami.rect.colliderect(tina.rect) and (random.random() < 0.45):
                                aami.crunched = True
                                if random.random() > 0.1:
                                    crunch.play()
                            # tina can now crunch AAMIs
                    if tina is not None:
                        if tina.rect.colliderect(player.rect):
                            player.crunched = True
                            crunch.play()
                            pygame.display.set_caption("You lost | %s" % TITLE)
                        tina.update_logic()
                    else: pass # there is no tina fey (only Zuhl)
                    if flags.you_won: # do happy/walking texture on player
                        player.surf.fill((0,0,0,0))
                        player.surf.blit(pygame.transform.flip(player.walking1,
                                                               bool(player.direction), False), (0,0))
                    if before_AAMIs_crunched != AAMIs_crunched:
                        print(f"AAMIs crunched: {AAMIs_crunched}                 ")
                        if AAMIs_crunched > 40 and you_won_fname is ...: # leave ellipsis in
                            you_won_fname = os.path.join('assets', 'you_won.png')
                            #print("Generated you_won_fname")
                        if AAMIs_crunched > 45 and you_won is ...: #       leave ellipsis in
                            you_won = pygame.image.load(you_won_fname)
                            #print("Loaded you_won")
                        if AAMIs_crunched > 48 and winning_music is ...:
                            #print("Loading music for when you win :)")
                            winning_music = not None
                            pygame.mixer.music.load(stuuf.ra)
                        if rose_above(before_AAMIs_crunched, AAMIs_crunched, 50):
                            # you won
                            print("You won")
                            flags.you_won = True
                            pygame.display.set_caption("You Won! | AAMI crunching")
                            pygame.mixer.music.play(0)
                        del before_AAMIs_crunched
                    if random.randint(0,tinafey_likelihood) == 1 and tina is None: # rare, but can happen
                        # SPAWN A TINA FEY!!!!!!!!!!
                        tina = TinaFey(target=player)
                        if random.randint(0,32) < 2: # same
                            for i in range(random.randint(4,tinafey_likelihood)):
                                tinas.add(TinaFey(
                                    pos=(random.randint(0, scr_w),
                                         random.randint(0,scr_h))))
                elif event.type == ADD_AAMI:
                    # add an AAMI to the collection of AAMIs
                    new_AAMI = AAMI((0,random.randint(0,scr_h)))
                    AAMIs.add(new_AAMI)
                    del new_AAMI
                    # we also make an attempt to drop a hat for the player
                    # to catch and gain abilities from
                    dropped_hat = Hat()
                    if DEBUG: print(f'Adding hat {dropped_hat}')
                    falling_hats.add(dropped_hat)
                    del dropped_hat
                elif event.type == GET_FPS:
                    current_fps = tiktok.get_fps()
                    print(f"FPS: {current_fps}", end='\r')
                elif event.type == KEYDOWN:
                    if (keys := pygame.key.get_pressed())[K_ESCAPE]:
                        if flags.you_won:
                            pygame.mixer.music.stop()
                            AAMIs_crunched -= 50 # basically resets the game
                            flags.you_won = False
                        else:
                            flags.running = False
                            running = 0
                    elif keys[K_F3]:
                        flags.show_hitboxes = not flags.show_hitboxes
                """elif event.type == RESET: # doesn't happen, removed for omtimisation reasons
                    AAMIs_crunched = 1
                    flags = stuuf.Flags(running=True, you_won=False)
                    #next_AAMI_speed = 6"""
            scr.fill((1,1,1))
            showrects = flags.show_hitboxes
            scr.blit(player.surf, player.rect)
            scr.blit(currenthat.surf, currenthat.rect)
            if showrects:
                if player.crunching:
                    pygame.draw.rect(scr, (255,0,0), player.rect, 6)
                pygame.draw.rect(scr, (0,254, 1), player.rect, 3)
            player.update_keypresses(pygame.key.get_pressed())
            player.update_pos()
            currenthat.update_pos()
            if tina is not None:
                tina.update_pos()
                scr.blit(tina.surf, tina.rect)
                if showrects:
                    pygame.draw.rect(scr, (245, 1, 0), tina.rect, 5)
            for aami in AAMIs:
                scr.blit(aami.surf, aami.rect)
                if showrects:
                    pygame.draw.rect(scr, (0,1,245), aami.rect, 2)
                aami.update_pos()
            for harmless_tina in tinas:
                scr.blit(harmless_tina.surf, harmless_tina.rect) # caused much trouble...
            for hat in falling_hats:
                scr.blit(hat.surf, hat.rect)
                if showrects:
                    pygame.draw.rect(scr, (240,1,255), hat.rect, 4)
            renderscore(scr)
            if flags.you_won: scr.blit(you_won, (0,0))
            if player.crunched: scr.blit(you_died, (0,0))
            pygame.display.flip()
            tiktok.tick(FPS)
        except KeyboardInterrupt:
            flags.running = False
            break

    deathmsgs.close()

    pygame.quit()
    quit()
